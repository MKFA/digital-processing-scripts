import csv

def replace_value_in_csv(input_file, output_file, old_value, new_value):
    # Open the input CSV file for reading
    with open(input_file, mode='r', newline='', encoding='utf-8') as infile:
        reader = csv.reader(infile)
        new_rows = []  # Read all rows into a list

        # Iterate through the rows and replace the value where needed
        for row in reader:
            row = [new_value if cell == old_value else cell for cell in row]
            new_rows.append(row)
    
    # Open the output CSV file for writing
    with open(output_file, mode='w', newline='', encoding='utf-8') as outfile:
        writer = csv.writer(outfile)
        writer.writerows(new_rows)  # Write the modified rows back to the file

    print(f"Replaced '{old_value}' with '{new_value}' and saved to '{output_file}'.")

# Example usage:
input_file = '/Volumes/MKFA/ARCHIVES STORAGE/Born_digital_processing/test_copies/D-0240/reports/appraisal/D-0240_deaccesssions.csv'
output_file = '/Volumes/MKFA/ARCHIVES STORAGE/Born_digital_processing/test_copies/D-0240/reports/appraisal/D-0240_deaccesssions_technical.csv'
old_value = 'scope'
new_value = 'Technical'

replace_value_in_csv(input_file, output_file, old_value, new_value)
