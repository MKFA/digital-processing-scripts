import os
from pathlib import Path

def add_text_to_file_in_directory(directory, text_to_add):
    # Walk through the directory tree
    for dir in os.listdir(directory): 
        dir_path = Path(directory, dir)
        info_path = dir_path / f"reports/{dir}_processing.info"
        if info_path.exists():
            # Open the file in append mode and add the text
            with open(info_path, 'a', encoding='utf-8') as file:
                file.write(text_to_add + '\n')
            print(f"Text added to {info_path}")
        else:
            # Open the file in append mode and add the text
            with open(info_path, 'w', encoding='utf-8') as file:
                file.write(text_to_add + '\n')
            print(f"{info_path} created and text added")


# Example usage
directory_to_search = '/path/to/your/directory'
target_filename = 'your_target_file.txt'
text_to_add = 'This is the text that will be added to the file.'

add_text_to_file_in_directory(directory_to_search, target_filename, text_to_add)
